﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment_4_VP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<string> collection;
      
        public MainWindow()
        {
            InitializeComponent();
            collection = new ObservableCollection<string>();
           

            DataContext= this;
        }

        private void b1_Click(object sender, RoutedEventArgs e)
        {
            collection.Add(textbox.Text);
            Listbox.Items.Add(textbox.Text);
        }

        private void b2_Click(object sender, RoutedEventArgs e)
        {
            if(Listbox.SelectedItem != null)
            {
                Listbox.Items.Remove(Listbox.SelectedItem);
            }
        }
    }

    
}